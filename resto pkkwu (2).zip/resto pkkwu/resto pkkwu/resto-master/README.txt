
TITLE: 
Resto - 100% Fully Responsive HTML5 Bootstrap 4 Template for Restaurants

AUTHOR:
DESIGNED & DEVELOPED by GetTemplates.co and FreeHTML5.co

Websites: https://gettemplates.co https://freehtml5.co/


CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

OwlCarousel
https://owlcarousel2.github.io/OwlCarousel2/

IsotopeSelect2
https://select2.org

Featherlight
https://noelboss.github.io/featherlight/

Stellar
http://markdalgleish.com/projects/stellar.js/

Tempus Dominus
https://tempusdominus.github.io/bootstrap-4/

Demo Images:
http://unsplash.com

